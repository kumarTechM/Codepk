package Conceptof.throwandthrows;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Exampleofthrows {

	public static void main(String[] args) throws FileNotFoundException 
	{
		FileInputStream fis= new FileInputStream("path of file");
		

	}
	
	
	
}
