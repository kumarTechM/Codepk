package regarding_Constructor;

public class Use_OF_Constructor2 {
	
	// we can called already initalize instance /static variable in constructor 
	int a=10;
	static int b=20;
	Use_OF_Constructor2()
	{
		System.out.println(a);
		System.out.println(b);
		
	}

   
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
