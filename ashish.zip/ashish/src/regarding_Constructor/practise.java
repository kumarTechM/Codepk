package regarding_Constructor;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class practise 
{
	
	public static void main(String[] args) 
	{
		DesiredCapabilities cap= new DesiredCapabilities();
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, True);
		
		
		
	}

}
