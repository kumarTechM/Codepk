package regarding_Constructor;

public class modifier_for_Constructor

{
	 private modifier_for_Constructor()
	 {
		 
	 }
	 protected modifier_for_Constructor(int a)
	 {
		 
	 }
	 public modifier_for_Constructor(float b)
	 {
		 
	 }
	

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
