package examples_exception_handling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;

public class Trycathcblock 
{
	public static void main(String[] args) // throws ArithmeticException
	{  
        
        int data=50/0; //may throw exception   (unchecked exception )
          
        System.out.println("rest of the code");  
          
    } 
	
	
}
	
	
	
	

