package examples_exception_handling;

public class Try_With_return {

	public static void main(String[] args) 
	{
		try
		{
			return;
		}
		finally
		{
			System.out.println("kjhskjfh");
		}
		

	}

}
