package capturing_screenshot_using_listner;
public class ExecutionflowofInheritance 
{
	int a=20;
	
	public static void m1()
	{
		int  a=10;
		System.out.println();
	}
	public static void main(String[] args) 
	{
		m1();
		
		
		
	}

}


