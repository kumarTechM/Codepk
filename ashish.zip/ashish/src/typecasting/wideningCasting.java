package typecasting;

public class wideningCasting {

	public static void main(String[] args)
	
	{
		int a=10;
		double d=a;// wideningcasting or automatic casting 
		System.out.println("double value is "+d);
		System.out.println("int value is "+a);

	}

}
