package typecasting;

public class narrowingcasting {

	public static void main(String[] args) 
	{
		double d=20.90;
		int a=(int) d;//narrowing or manual casting

		System.out.println("int value is "+a);
		System.out.println("double value is "+d);
	}

}
