package ConceptOFList;

import java.util.ArrayList;

public class GenericArrayList {

	public static void main(String[] args) 
	{
		ArrayList<String> list=new ArrayList<String>();
		list.add("pravin");
		list.add("100");
		list.add("sarkate");
		list.add("ashish");
		System.out.println(list);
		
		

	}

}
