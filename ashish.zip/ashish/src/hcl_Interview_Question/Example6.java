package hcl_Interview_Question;

public class Example6 extends a
{

	public static void main(String[] args) 
	{
		//Example6 n= new Example6();

	}

}
class a
{
	a()
	{
		System.out.println("parent class con");
	}
}