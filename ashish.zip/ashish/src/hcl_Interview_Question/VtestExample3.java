package hcl_Interview_Question;

public class VtestExample3 extends navin
{

	public static void main(String[] args) 
	{
	navin n=new navin(6);
		

	}

}
class navin
{
	navin()
	{
		System.out.println("0-arg constructor");
	}
	navin(int i)
	{
		System.out.println("1-arg constructor");
	}
}
