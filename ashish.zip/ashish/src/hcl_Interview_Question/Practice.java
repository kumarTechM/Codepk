package hcl_Interview_Question;

import java.util.HashMap;
import java.util.HashSet;

public class Practice 
{
	

	public static void main(String[] args) 
	{
		String s="pravinpravin";
		

	}

}
