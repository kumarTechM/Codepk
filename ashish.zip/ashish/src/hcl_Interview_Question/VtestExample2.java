package hcl_Interview_Question;

public class VtestExample2 {

	public static void main(String[] args) 
	{
		p.i=40;// varibale present in interface is always public static final
		System.out.println(p.i);
		

	}

}
interface p
{
	int i=20;
	
}