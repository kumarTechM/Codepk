package programming;

import java.util.Arrays;

public class ArrangingCharacterFromgivenString {

	public static void main(String[] args) 
	{
		String s="pravinzaiopuza";
		char [] ch=s.toCharArray();
		Arrays.sort(ch);
		System.out.println(ch);

	}

}
