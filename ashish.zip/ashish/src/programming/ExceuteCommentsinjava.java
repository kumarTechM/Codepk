package programming;

public class ExceuteCommentsinjava {

	public static void main(String[] args)
	
	{ 
		//hkjhjkhjk\u000d 	System.out.println("ashu");
		System.out.println("sarkate");
		\u000d
		System.out.println(\u000d);// it will create new line
		System.out.println("pravin");
		
		// TODO Auto-generated method stub

	}

}
