package programming;

public class CompareInteger {

	public static void main(String[] args) 
	{
		// Concept of integer caching whos range is -128 to + 127
		Integer a=190;// Integer wraper class
		Integer b=190;
		if(a==b)
		{
			System.out.println("numbers are equal");
		}
		else
		{
			System.out.println("numbers are not equal");
		}
		int c=190;
		int d=190;
		if(c==d)
		{
			System.out.println("numbers are equal");
		}
		else
		{
			System.out.println("numbers are not equal");
		}

	}

}
