package programming;

public class Printing1to100WithoutNumber {

	public static void main(String[] args) 
	{
		int one='A'/'A';
		
		for(int i=one;i<='d';i++)
		{
			
			System.out.println(i);
			
		}

	}

}
