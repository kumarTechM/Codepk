package oops;

public class PublicORDeafult extends p
{

	

}



