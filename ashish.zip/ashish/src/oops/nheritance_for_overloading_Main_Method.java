package oops;

//if child dosen't have main method then parent class main method will execute
public class nheritance_for_overloading_Main_Method extends pravin1
{

	// int a=10;
	/*public void m1()
		{
			System.out.println("overrded method");
		}*/


	m
	// if u provide this method and not providing main method we will get ce(Could not find or load main)
}
class pravin1
{
	public void m1()
	{
		System.out.println("m1");
	}
	public static void main(String[] args)
	{
		System.out.println("parent class method");

	}
}