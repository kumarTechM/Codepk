package codes;

public class Substring {

	public static void main(String[] args) 
	{
		String s="$127.123";
	//	System.out.println(s.substring(0));
		System.out.println(s.substring(1, 4));

	}

}
