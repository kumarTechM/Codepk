package codes;

import java.util.Arrays;
import java.util.List;

public class Arrays_Concept {

	public static void main(String[] args) 
	{
		String s[]= {"a","x","z","b","w"};
		List<String> l=Arrays.asList(s);
		System.out.println(l);
		//l.add("p");
		System.out.println(l);

	}

}
