package codes;

public class ExceptionDto {

	public static void main(String[] args) {
		
			try {
				int a=10/0;
				System.out.println("arithj");
			} 
			catch( Exception e)
			{
				
			}
	
		
	}

}
