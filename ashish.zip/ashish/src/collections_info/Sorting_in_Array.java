package collections_info;

import java.util.Arrays;

public class Sorting_in_Array {

	public static void main(String[] args) 
	{
		 char a[]= {'a','z','b','d'};
		 Arrays.sort(a);
		 for (char c : a)
		 {
			 System.out.println(c);
			
		}
		 
		 // binary searching
		 System.out.println(Arrays.binarySearch(a, 'c'));
		 //reversing
	//	 Arrays
	}

}
