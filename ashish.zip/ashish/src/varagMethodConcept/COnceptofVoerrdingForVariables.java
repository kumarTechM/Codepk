
package varagMethodConcept;

public class COnceptofVoerrdingForVariables extends v

{
	int x=900;
	// for variable there is not concept like overriding 

	public static void main(String[] args) 
	{
		COnceptofVoerrdingForVariables v= new COnceptofVoerrdingForVariables();
		System.out.println(v.x);
	v z	= new COnceptofVoerrdingForVariables();
	System.out.println(z.x);

	}

}
class v
{
	int x=800;
}